#include "MRIOExtras.h"

namespace MR
{

void loadIOExtras()
{
    //
}

} // namespace MR
