#pragma once

#include "exports.h"

namespace MR
{

MRIOEXTRAS_API void loadIOExtras();

} // namespace MR
