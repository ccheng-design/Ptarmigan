#pragma once

#include "MRCircleObject.h"
#include "MRConeObject.h"
#include "MRCylinderObject.h"
#include "MRLineObject.h"
#include "MRPlaneObject.h"
#include "MRPointObject.h"
#include "MRSphereObject.h"
