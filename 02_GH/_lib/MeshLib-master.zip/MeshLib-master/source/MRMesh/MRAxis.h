#pragma once

namespace MR
{
 enum class Axis
 {
     X,
     Y,
     Z,
     Count
 };
}
