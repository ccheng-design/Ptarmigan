import sys

print("--------------")
print(len(sys.argv))
print("--------------")
for arg in sys.argv:
	print(arg)

print("--------------")